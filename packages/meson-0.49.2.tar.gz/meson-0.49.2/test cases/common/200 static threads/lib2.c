extern void *f(void);

void *g(void) {
  return f();
}

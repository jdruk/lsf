#include "hdr.h"

#if !defined(SOME_DEFINE) || SOME_DEFINE != 42
#error "Should have picked up hdr.h from inc1/hdr.h"
#endif

int
main (int c, char ** argv)
{
  return 0;
}

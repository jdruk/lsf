#pragma once

#define MESSAGE "Hello there.\n"

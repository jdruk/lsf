int libfunc() {
    return 3;
}

int internal_function() {
    return 42;
}

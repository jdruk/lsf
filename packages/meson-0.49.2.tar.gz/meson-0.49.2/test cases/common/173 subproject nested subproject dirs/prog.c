int func();

int main(int argc, char **argv) {
    return func() == 42 ? 0 : 1;
}

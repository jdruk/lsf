int dir3_dir1 = 31;

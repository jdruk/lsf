#include<mylib.h>

int main(int argc, char **argv) {
    return func1() - func2();
}
